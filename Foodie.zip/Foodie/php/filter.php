<form class="px-4 py-3">
    <div class="row justify-content-center">
        <div class="col">
            <select class="form-select mx-3 my-2" aria-label="Default select example">
                <option selected>Food type</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
            </select>
        </div>
        <div class="col">
            <select class="form-select mx-3 my-2" aria-label="Default select example1">
                <option selected>Resturents</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
            </select>
        </div>
        <div class="col">
            <select class="form-select mx-3 my-2" aria-label="Default select example1">
                <option selected>Location</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
            </select>
        </div>
        <div class="col">
            <select class="form-select mx-3 my-2" aria-label="Default select example">
                <option selected>Rating</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
            </select>
        </div>
        <div class="col">
            <select class="form-select mx-3 my-2" aria-label="Default select example1">
                <option selected>Price</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
            </select>
        </div>
    </div>
    <div class="row justify-content-center">
        <input class="button col-3 filter-btn btn btn-danger" type="reset" name="reset" value="Reset">
        <input class="button col-3 filter-btn btn btn-success" type="submit" name="apply" value="Apply">
    </div>
</form>