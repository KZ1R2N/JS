-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2023 at 01:44 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodie`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `Rev_Id` int(100) NOT NULL,
  `Rev_name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Food_name` varchar(100) NOT NULL,
  `Rating` double NOT NULL,
  `Comment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`Rev_Id`, `Rev_name`, `Email`, `Username`, `Food_name`, `Rating`, `Comment`) VALUES
(1, 'medha', 'medha@gmail.com', 'medha123', 'Pizza', 4, 'Good'),
(2, 'afia', 'afia@gmail.com', 'afia', 'Burger', 3.5, 'Good but need more juicy.'),
(3, 'faruk', 'faruk@gmail.com', 'faruk123', 'pasta', 4, 'Good but need more cheese.'),
(4, 'Ratun', 'ratun@gmail.com', 'ratun123', 'fried chicken ', 4, 'good'),
(5, 'Rajib', 'rajib@gmail.com', 'rajib123', 'Hot dog', 2, 'worst item ever try in my life.'),
(6, 'Jui', 'jui@gmail.com', 'jui123', 'garlic chicken', 4.5, 'Best one garlic ever tried in my life.'),
(7, 'Abid', 'abid@gmail.com', 'abid123', 'chicken lolipop', 4, 'Good but need more quantity.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`Rev_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
