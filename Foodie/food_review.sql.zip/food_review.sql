-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2023 at 03:07 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodie`
--

-- --------------------------------------------------------

--
-- Table structure for table `food_review`
--

CREATE TABLE `food_review` (
  `rev_id` int(11) NOT NULL,
  `rev_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `food_name` varchar(255) NOT NULL,
  `rating` float DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `food_review`
--

INSERT INTO `food_review` (`rev_id`, `rev_name`, `email`, `username`, `food_name`, `rating`, `comment`) VALUES
(1, 'medha', 'medha@gmail.com', 'medha123', 'Pizza', 4.5, 'quality was good but quantity was not satisfied.'),
(2, 'afia', 'afia@gmail.com', 'afia123', 'chicken wings', 4, 'too spicy'),
(3, 'faruk', 'faruk@gmail.com', 'faruk123', 'fried chicken', 4, 'good but need more chicken'),
(4, 'ratun', 'ratun@gmail.com', 'ratun123', 'pasta', 4, 'good but need more juicy'),
(5, 'rajib', 'rajib@gmail.com', 'rajib123', 'hot dog', 3, 'not so good. Need more masala '),
(6, 'abid', 'abid@gmail.com', 'abid123', 'garlic chicken', 4, 'piece was so small. have to make better quantity'),
(7, 'jui', 'jui@gmail.com', 'jui123', 'chicken lolipop', 4.5, 'good'),
(8, 'rafi', 'rafi@gmail.com', 'rafi', 'meatbox', 4, 'need more meat and sausage'),
(9, 'Alina', 'alina@gmail.com', 'alina123', 'fried rice', 5, 'Best one i tried ever'),
(10, 'Eshal', 'eshal@gmail.com', 'eshal123', 'soup', 4, 'quality have to make better'),
(11, 'adiba', 'adiba@gmail.com', 'adiba123', 'noodles', 4, 'taste was good but quantity was not satisfied'),
(12, 'semim', 'semim@gmail.com', 'semim123', 'french fry', 3.5, 'good'),
(13, 'oishi', 'oishi@gmail.com', 'oishi123', 'pasta', 3, 'average basis on price'),
(14, 'fiza', 'fiza@gmail.com', 'fiza123', 'ramen', 4, 'too spicy but overall good'),
(15, 'adit', 'adit@gmail.com', 'adit123', 'kabab', 5, 'Best');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `food_review`
--
ALTER TABLE `food_review`
  ADD PRIMARY KEY (`rev_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `food_review`
--
ALTER TABLE `food_review`
  MODIFY `rev_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
